<?php 

function st_cm_light_slider(){
	$labels = array(
    'name' => _x('Light Slider', 'post type general name'),
    'singular_name' => _x('Light Slider', 'post type singular name'),
    'all_items' => __('View Slides'),
  );
  $args = array(
    'labels' => $labels,
    'public' => true,
    'publicly_queryable' => true,
    'show_ui' => true, 
    'show_in_menu' => true, 
    'query_var' => true,
    'rewrite' => true,
    'capability_type' => 'post',
    'has_archive' => true, 
    'hierarchical' => false,
    'menu_icon'           => 'dashicons-images-alt2',
    'menu_position' => null,
    'supports' => array( 'title', 'editor', 'thumbnail' )
  ); 
  register_post_type('cm_light_slider',$args);
}

function st_cm_sh_light_slider(){

    $wrap_container = (get_option('st_light_slider_wrap_container') == 'on')? 'checked' : '';

    $result .= "";

    $args = array( 'post_type' => 'cm_light_slider', 'order' => 'ASC' );
    $loop = new WP_Query( $args );

    $result .= '<ul id="st-light-slider">';

        $count = 1;
        while ( $loop->have_posts() ) : $loop->the_post();
            $result .= '<li class="slide-'.$count.'"';

                if ( has_post_thumbnail() ){
                    $result .= ' style="background-image: url(\''.get_the_post_thumbnail_url().'\');  background-repeat: no-repeat; background-size: cover; background-position: center; height: 100%; " ';
                }

            $result .= '>'; // <li> starts

            $result .= '<div class="slider_text_inner">';

            if( $wrap_container )
                $result .= '<div class="container">';
                
            $result .= get_the_content();
            
            if( $wrap_container )
                $result .= '</div>';

            $result .= '</div>';
            
            $result .= '</li>';

            $count++;
        endwhile;

    $result .= '</ul>';

    return $result;
}


function st_cm_slider_script() {
?>
    <script type="text/javascript">
        if ( undefined !== window.jQuery ) {
            var slider =  $('#st-light-slider').lightSlider({
                item: 1,
                slideMove: 1,
                slideMargin: 0,
                enableDrag: false,
                loop: true,

                <?php echo esc_attr( get_option('st_light_slider_cm_js_settings') ); ?> 

                <?php if(esc_attr( get_option('st_light_slider_cm_effect') ) == 'fade'): ?>
                    onBeforeSlide: function (el) {
                        $('#st-light-slider li .slider_text_inner').fadeOut(0);
                    },
                    onAfterSlide: function (el) {
                        $('#st-light-slider li .slider_text_inner').fadeIn(<?php echo esc_attr( get_option('st_light_slider_anim_speed', 500) ); ?>);
                    },
                <?php endif; ?>

                <?php if(esc_attr( get_option('st_light_slider_cm_effect') ) == 'fade-slide-up'): ?>
                    onBeforeSlide: function (el) {
                        $('#st-light-slider li .slider_text_inner').css({'opacity':'0'});
                    },
                    onAfterSlide: function (el) {
                        $('#st-light-slider li .slider_text_inner').css({'margin-top':'8px'}).animate({'margin-top':'0px','opacity':'1'}, <?php echo esc_attr( get_option('st_light_slider_anim_speed', 500) ); ?>);
                    },
                <?php endif; ?>
                
            });

            <?php if(get_option('st_light_slider_cm_hover_stop') == 'on'): ?>
                    slider.on('mouseenter',function(){
                        slider.pause();
                    });
                    slider.mouseleave(function() {
                        setTimeout(function () {
                            slider.play();
                        }, 2000);
                    });
                <?php endif; ?>
            
            <?php echo esc_attr( get_option('st_light_slider_cm_js') ); ?>
        }
    </script>

    <style type="text/css">
        .lSAction > .lSPrev{ left: 0; }
        .lSAction > .lSNext{ right: 0; }
        #st-light-slider{
            -webkit-touch-callout: text; /* iOS Safari */
                -webkit-user-select: text; /* Safari */
                 -khtml-user-select: text; /* Konqueror HTML */
                   -moz-user-select: text; /* Firefox */
                    -ms-user-select: text; /* Internet Explorer/Edge */
                        user-select: text; /* Non-prefixed version, currently */
        }
        #st-light-slider{
            color: <?php echo esc_attr( get_option('st_light_slider_font_color') ); ?>;
        }
        #st-light-slider .container{
            padding: <?php echo esc_attr( get_option('st_light_slider_padding_top') ); ?>px <?php echo esc_attr( get_option('st_light_slider_padding_right') ); ?>px <?php echo esc_attr( get_option('st_light_slider_padding_bottom') ); ?>px <?php echo esc_attr( get_option('st_light_slider_padding_left') ); ?>px;
        }
        .lSAction>a{
            font-family: FontAwesome;
        }
        .lSAction .lSPrev:before{
            content: '\<?php echo esc_attr( get_option('st_light_slider_arrow_left', 'f104') ); ?>';
        }
        .lSAction .lSNext:before{
            content: '\<?php echo esc_attr( get_option('st_light_slider_arrow_right', 'f105') ); ?>';
        }
        
    </style>

<?php
}


function st_cm_settings(){
    add_submenu_page('edit.php?post_type=cm_light_slider', 'Settings', 'Settings', 'manage_options', 'light-slider-settings', 'st_cm_settings_html' );
}

function st_cm_settings_html(){

    $container = get_option('st_light_slider_wrap_container' , 'true');
    $container_selected = ($container)? 'checked' : '';

    ?>

    <form method="post" action="options.php">
        <?php settings_fields( 'st-slider-settings-group' ); ?>
        <?php do_settings_sections( 'st-slider-settings-group' ); 

            $wrap_container = (get_option('st_light_slider_wrap_container') == 'on')? 'checked' : '';
            $hover_stop = (get_option('st_light_slider_cm_hover_stop') == 'on')? 'checked' : '';

        ?>

        <div style="margin-right: 20px;padding: 8px;margin-top: 22px;background: #fff;border: 1px solid #e2e2e2;border-radius: 2px;">Light slider script & style is required for this plugin</div>
        <div style="margin-right: 20px;padding: 8px;margin-top: 22px;background: #fff;border: 1px solid #e2e2e2;border-radius: 2px;">Shortcode: &nbsp;<strong>[light_slider]</strong></div>

        <table class="form-table">
            <tr valign="top">
                <th scope="row">Wrap Container</th>
                <td><input type="checkbox" name="st_light_slider_wrap_container" <?php echo $wrap_container; ?> /></td>
            </tr>

            <tr valign="top">
                <th scope="row">Container Padding</th>
                <td>
                    <input type="number" name="st_light_slider_padding_top" value="<?php echo esc_attr( get_option('st_light_slider_padding_top') ); ?>" style="max-width: 60px;" />
                    <input type="number" name="st_light_slider_padding_right" value="<?php echo esc_attr( get_option('st_light_slider_padding_right') ); ?>" style="max-width: 60px;" />
                    <input type="number" name="st_light_slider_padding_bottom" value="<?php echo esc_attr( get_option('st_light_slider_padding_bottom') ); ?>" style="max-width: 60px;" />
                    <input type="number" name="st_light_slider_padding_left" value="<?php echo esc_attr( get_option('st_light_slider_padding_left') ); ?>" style="max-width: 60px;" />
                </td>
            </tr>

            <tr valign="top">
                <th scope="row">Default Font Color</th>
                <td><input type="color" name="st_light_slider_font_color" value="<?php echo esc_attr( get_option('st_light_slider_font_color') ); ?>" /></td>
            </tr>

            <tr valign="top">
                <th scope="row">Additional Js Slide Settings</th>
                <td><textarea name="st_light_slider_cm_js_settings"><?php echo esc_attr( get_option('st_light_slider_cm_js_settings') ); ?></textarea></td>
            </tr>

            <tr valign="top">
                <th scope="row">Additional Js Settings</th>
                <td><textarea name="st_light_slider_cm_js"><?php echo esc_attr( get_option('st_light_slider_cm_js') ); ?></textarea></td>
            </tr>

            <tr valign="top">
                <th scope="row">Effect</th>
                <td>
                    <?php $effect_selected = esc_attr( get_option('st_light_slider_cm_effect') ); ?>
                    <select name="st_light_slider_cm_effect">
                        <option value="none">- None -</option>
                        <option value="fade" <?php echo ($effect_selected == 'fade')? 'selected="selected" ':''; ?>>Fade Effect</option>
                        <option value="fade-slide-up" <?php echo ($effect_selected == 'fade-slide-up')? 'selected="selected" ':''; ?>>Fade - Slide Effect</option>
                    </select>
                </td>
            </tr>

            <tr valign="top">
                <th scope="row">Animation Speed</th>
                <td>
                    <input type="number" name="st_light_slider_anim_speed" value="<?php echo esc_attr( get_option('st_light_slider_anim_speed') ); ?>" /> <i>Default Animation Speed: 500</i>
                </td>
            </tr>

            <!--<tr valign="top">
                <th scope="row">Stop On Hover</th>
                <td><input type="checkbox" name="st_light_slider_cm_hover_stop" <?php echo $hover_stop; ?> /></td>
            </tr>
            -->
            
            <tr valign="top">
                <th scope="row">Directional Arrows FontAwesome</th>
                <td>
                    <input type="text" name="st_light_slider_arrow_left" value="<?php echo esc_attr( get_option('st_light_slider_arrow_left', 'f104') ); ?>" style="max-width: 80px;" placeholder="left"/>
                    <input type="text" name="st_light_slider_arrow_right" value="<?php echo esc_attr( get_option('st_light_slider_arrow_right', 'f105') ); ?>" style="max-width: 80px;" placeholder="right"/> <i>eg: <b>f104</b></i>
                </td>
            </tr>

        </table>
        
        <?php submit_button(); ?>

    </form>

<pre style="background-color: #e2e2e2; border-radius: 4px; margin-right: 22px; padding: 30px 40px;">
<h4 style="margin-bottom: 0px">Additional Js Settings</h4>
slider.goToSlide(3);
slider.goToPrevSlide();
slider.goToNextSlide();
slider.getCurrentSlideCount();
slider.refresh();
slider.play(); 
slider.pause();    
</pre>

<pre style="background-color: #e2e2e2; border-radius: 4px; margin-right: 22px; padding: 30px 40px;">
<h4 style="margin-bottom: 0px">Additional Js Slide Settings</h4>
item: 3,
autoWidth: false,
slideMove: 1, // slidemove will be 1 if loop is true
slideMargin: 10,

addClass: '',
mode: "slide",
useCSS: true,
cssEasing: 'ease', //'cubic-bezier(0.25, 0, 0.25, 1)',//
easing: 'linear', //'for jquery animation',////

speed: 400, //ms'
auto: false,
loop: false,
slideEndAnimation: true,
pause: 2000,

keyPress: false,
controls: true,
prevHtml: '',
nextHtml: '',

rtl:false,
adaptiveHeight:false,

vertical:false,
verticalHeight:500,
vThumbWidth:100,

thumbItem:10,
pager: true,
gallery: false,
galleryMargin: 5,
thumbMargin: 5,
currentPagerPosition: 'middle',

enableTouch:true,
enableDrag:true,
freeMove:true,
swipeThreshold: 40,

responsive : [],

</pre>

    <?php
}

function st_cm_save_settings() {
    register_setting( 'st-slider-settings-group', 'st_light_slider_wrap_container' );
    register_setting( 'st-slider-settings-group', 'st_light_slider_font_color' );

    register_setting( 'st-slider-settings-group', 'st_light_slider_padding_top' );
    register_setting( 'st-slider-settings-group', 'st_light_slider_padding_right' );
    register_setting( 'st-slider-settings-group', 'st_light_slider_padding_bottom' );
    register_setting( 'st-slider-settings-group', 'st_light_slider_padding_left' );

    register_setting( 'st-slider-settings-group', 'st_light_slider_cm_js_settings' );
    register_setting( 'st-slider-settings-group', 'st_light_slider_cm_js' );

    register_setting( 'st-slider-settings-group', 'st_light_slider_cm_effect' );
    register_setting( 'st-slider-settings-group', 'st_light_slider_anim_speed' );

    register_setting( 'st-slider-settings-group', 'st_light_slider_arrow_left' );
    register_setting( 'st-slider-settings-group', 'st_light_slider_arrow_right' );

    register_setting( 'st-slider-settings-group', 'st_light_slider_cm_hover_stop' );
}
