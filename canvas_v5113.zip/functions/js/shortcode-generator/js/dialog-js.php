<?php
/**
 * DEPRECATED
 * @since  6.2.7
 * Logic moved into admin-shortcode-generator.php and dialog.js
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) exit;
?>
